@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>RBLXDev</h2>
        <p>Maintenance time! Small changes from the outside, big changes inside!</p>
    </div>
@endsection
