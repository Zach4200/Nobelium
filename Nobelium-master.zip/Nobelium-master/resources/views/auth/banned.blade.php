@extends('layouts.app')

@section('content')
    <div class="container">
        <h3>Banned from RBLXhue</h3>
        <p>You were banned from RBLXhue. It was probably not nice knowing you. Bye.</p>
    </div>
@endsection
