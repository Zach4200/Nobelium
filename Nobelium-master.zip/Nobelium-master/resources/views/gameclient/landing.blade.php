@extends('layouts.app')

@section('content')
    <div class="container">
        <h3>Welcome to RBLXDev.</h3>
        <p>Still a WIP.</p>
    </div>
@endsection
