<?xml version="1.0" encoding="utf-8" ?>
<roblox xmlns:xmime="http://www.w3.org/2005/05/xmlmime" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://www.roblox.com/roblox.xsd" version="4">
	<External>null</External>
	<External>nil</External>
	<Item class="BodyColors">
		<Properties>
			<int name="HeadColor">{{ $colors->head_color }}</int>
			<int name="LeftArmColor">{{ $colors->left_arm_color }}</int>
			<int name="LeftLegColor">{{ $colors->left_leg_color }}</int>
			<string name="Name">Body Colors</string>
			<int name="RightArmColor">{{ $colors->right_arm_color }}</int>
			<int name="RightLegColor">{{ $colors->right_leg_color }}</int>
			<int name="TorsoColor">{{ $colors->torso_color }}</int>
			<bool name="archivable">true</bool>
		</Properties>
	</Item>
</roblox>