<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>RBLXDev</title>
    </head>
    <body>
        <h1>RBLXDev</h1>

        <p>RBLXDev is making a return soon, with 99.5% less copyrighted content, 40% less dictatorship, and 100% more huebr!</p>
        <p><a href="//forum.rblxdev.pw/">Click here to go to the forums.</a></p>
        <br>
        <p>-Raymonf</p>
        <p>5/15/2016</p>
    </body>
</html>