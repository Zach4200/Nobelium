@extends('layouts.app')

@section('content')
	<div class="container">
		<h3>Downloads</h3>
		<p>We can't provide downloads because #murica and #freedom. Also, both Trump and Hillary are idiots. Why? Fuck you, that's why.</p>
		<p>You can, however, ask someone that plays off the site (Skype, etc.) for the client.</p>
	</div>
@endsection
